/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.supermarket;

/**
 *
 * @author Admin
 */
public class Supermarket {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        Login l = new Login();
        
        l.setVisible(true);
    }
}
